EK Messenger - د Android APK سرچینه

دا د Android Studio د پروژې سرچینه ده، APK فایل نه دی.
د APK جوړولو لپاره:
1) دا ZIP په کمپیوټر کې خلاص کړئ.
2) فولډر په Android Studio کې Open کړئ.
3) د Gradle Sync بشپړېدو ته انتظار وباسئ.
4) Build > Build Bundle(s) / APK(s) > Build APK(s) وټاکئ.
5) APK د app/build/outputs/apk/debug/app-debug.apk په مسیر کې پیدا کېږي.

مهم:
- دا یوازې د ډیمو WebView اپ دی.
- پیغامونه یوازې په همدې وسیله کې ښکاري؛ بل کاروونکي ته نه رسېږي.
- د SMS تایید، انلاین چټ، عکس/ویډیو اپلوډ، خبرتیاوې او سرور لا نه دي نښلول شوي.
- د حقیقي خدمت لپاره خوندي backend، database، د کاروونکو تصدیق او د SMS provider ته اړتیا ده.
